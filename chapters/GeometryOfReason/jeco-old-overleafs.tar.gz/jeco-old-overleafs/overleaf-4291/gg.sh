rm -v -r ./auto/
git add .
git commit
