rm -v -r ./auto/
rm -v *.*~
git add .
git commit -a
git push
